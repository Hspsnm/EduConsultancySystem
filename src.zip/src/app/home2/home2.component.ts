import { Component } from '@angular/core';
import { NavbarComponent } from '@app/navbar/navbar.component';
@Component({
  selector: 'app-home2',
  standalone: true,
  imports: [NavbarComponent],
  templateUrl: './home2.component.html',
  styleUrl: './home2.component.css'
})
export class Home2Component {

}
