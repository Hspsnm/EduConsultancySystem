import { Component } from '@angular/core';
import { NavbarComponent } from '@app/navbar/navbar.component';
@Component({
  selector: 'app-home1',
  standalone: true,
  imports: [NavbarComponent],
  templateUrl: './home1.component.html',
  styleUrl: './home1.component.css'
})
export class Home1Component {

}
